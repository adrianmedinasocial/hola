<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-visual-editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv-page-section tve-height-update">
	<div class="tve-page-section-out"></div>
	<div class="tve-page-section-in tve_empty_dropzone"></div>
</div>

