<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 5/26/2017
 * Time: 4:43 PM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv_post_grid tcb-elem-placeholder">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'post_grid', false, 'editor' ); ?>
		<?php echo esc_html__( 'Add post grid', 'thrive-cb' ); ?>
	</span>
</div>
