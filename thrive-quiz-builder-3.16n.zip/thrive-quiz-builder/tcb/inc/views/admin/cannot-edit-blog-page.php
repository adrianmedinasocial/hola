<div class="update-nag"><?php echo esc_html__( 'This page is setup as a "Blog Page" from Wordpress Reading Settings. Thrive Architect cannot be loaded in such instances.', 'thrive-cb' ) ?></div>
