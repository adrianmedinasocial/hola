<div class="control-grid no-space wrap">
	<label for="v-v-url"><?php echo esc_html__( 'URL', 'thrive-cb' ) ?></label>
	<input type="text" data-setting="url" class="v-url fill" id="v-v-url">
</div>
<div class="vooplayer-url-validate inline-message"></div>
