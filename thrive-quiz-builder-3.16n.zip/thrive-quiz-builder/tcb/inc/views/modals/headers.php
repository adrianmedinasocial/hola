<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-visual-editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}

?>

<h2 class="tcb-modal-title"><?php echo esc_html__( 'Choose Header', 'thrive-cb' ); ?></h2>
