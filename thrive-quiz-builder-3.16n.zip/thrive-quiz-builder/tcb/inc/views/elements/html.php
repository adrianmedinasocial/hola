<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 4/18/2017
 * Time: 12:03 PM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv_custom_html_shortcode tcb-elem-placeholder">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'custom_html', false, 'editor' ); ?>
		<?php echo esc_html__( 'Insert Custom HTML', 'thrive-cb' ); ?>
	</span>
</div>
