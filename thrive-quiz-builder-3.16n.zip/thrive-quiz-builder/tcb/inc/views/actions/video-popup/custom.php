<div class="extra-settings">
	<div class="inline-checkboxes">
		<label class="tcb-checkbox"><input type="checkbox" data-setting="a" value="1" checked="checked"><span><?php echo esc_html__( 'Autoplay', 'thrive-cb' ) ?></span></label>
	</div>
</div>
