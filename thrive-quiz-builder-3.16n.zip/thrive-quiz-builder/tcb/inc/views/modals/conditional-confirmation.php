<div class="title"></div>
<div class="description"></div>
<div class="buttons-wrapper">
	<button class="cancel-action click" data-fn="cancelAction">
		<?php echo esc_html__( 'No, Cancel', 'thrive-cb' ); ?>
	</button>
	<button class="apply-action click" data-fn="applyAction"></button>
</div>