<div class="control-grid wrap">
	<label for="v-v-url">
		<?php echo esc_html__( 'URL', 'thrive-cb' ) ?>
	</label>
	<input type="text" data-setting="url" class="v-url tve_provider_url full-width" id="v-v-url" placeholder="e.g. https://vimeo.com/22676965">
</div>
<div class="inline-message"></div>
<div class="control-grid wrap no-space">
	<label>
		<?php echo esc_html__( 'Player color', 'thrive-cb' ) ?>
	</label>
	<div class="tcb-text-right v-setting-color full-width"></div>
</div>
